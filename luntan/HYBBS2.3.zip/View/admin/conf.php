<?php
return array(
	'name'=>'HYBBS默认后台模板',
	'mess'=>'HYBBS默认模板',
	'user'=>'krabs',
);