<?php
return array(
	'name'=>'HYBBS 默认搜索页模板',
	'mess'=>'HYBBS 默认搜索页模板',
	'user'=>'krabs',
);