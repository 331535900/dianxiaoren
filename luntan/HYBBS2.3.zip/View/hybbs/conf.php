<?php
return array(
    'name' => 'hybbs',
    'user' => 'admin',
    'mess' => 'HYBBS2.0重制模板',
    'code' => '',
    'version' => '2.21',
);