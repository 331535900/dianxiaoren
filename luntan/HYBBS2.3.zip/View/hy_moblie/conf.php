<?php
return array(
    'name' => '官方手机模板',
    'user' => 'krabs',
    'mess' => '官方手机模板',
    'code' => '',
    'version' => '2.91',
);